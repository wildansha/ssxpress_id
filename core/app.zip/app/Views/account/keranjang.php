<?= $this->extend('template'); ?>

<?= $this->section('main'); ?>

<main>
    <div class="container">
    

    </div>

</main>


</body>

<?= $this->endSection(); ?>